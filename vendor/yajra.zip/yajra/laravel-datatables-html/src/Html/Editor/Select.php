<?php

namespace Yajra\DataTables\Html\Editor;

class Select extends Field
{
    protected $type = 'select';
}
