<?php

namespace Yajra\DataTables\Html\Editor;

class TextArea extends Field
{
    protected $type = 'textarea';
}
