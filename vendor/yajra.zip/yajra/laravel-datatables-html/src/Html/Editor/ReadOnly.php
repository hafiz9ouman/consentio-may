<?php

namespace Yajra\DataTables\Html\Editor;

class ReadOnly extends Field
{
    protected $type = 'readonly';
}
