<?php

namespace Yajra\DataTables\Html\Editor;

class Number extends Field
{
}
