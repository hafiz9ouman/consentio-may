<?php

namespace Yajra\DataTables\Html\Editor;

class Text extends Field
{
}
