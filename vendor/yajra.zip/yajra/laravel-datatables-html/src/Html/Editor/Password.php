<?php

namespace Yajra\DataTables\Html\Editor;

class Password extends Field
{
    protected $type = 'password';
}
