<?php

namespace Yajra\DataTables\Html\Editor;

class Hidden extends Field
{
    protected $type = 'hidden';
}
