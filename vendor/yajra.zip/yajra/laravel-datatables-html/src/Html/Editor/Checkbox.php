<?php

namespace Yajra\DataTables\Html\Editor;

class Checkbox extends Field
{
    protected $type = 'checkbox';
}
