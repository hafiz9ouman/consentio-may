<?php

namespace Yajra\DataTables\Html\Editor;

class Radio extends Field
{
    protected $type = 'radio';
}
