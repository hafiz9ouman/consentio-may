<?php

namespace Yajra\DataTables;

use Exception;

class DataTablesEditorException extends Exception
{
}
