# Laravel DataTables Complete Package

## Change Log

### v1.2.0 - 11-02-2018

- Include DataTables Editor package.

### v1.1.0 - 08-16-2018

- Add support for buttons v4.x.

### v1.0.0 - 08-31-2017

- First stable version.
